

function create_Resume()
{


const name = document.getElementById("name").value;
const contact = document.getElementById("contact").value;

 const qualificationNodes = document.querySelectorAll('input[name="qualification"]:checked');
    let qualifications = [];
    qualificationNodes.forEach((q) => {
        qualifications.push(q.value);
    });
    const qualification = qualifications.join(", "); 



const experience = document.getElementById("experience").value;
const skills = document.getElementById("skills").value;

document.getElementById("Resume").innerHTML =
"<h3>" + name + "</h3>" +
"<p><b>Contact:</b> " + contact  + "</p>" +
"<p><b>qualification:</b> " + qualification + " </p>"+
"<p><b>Job Experience:</b>  " + experience + " </p>" +
"<p><b>Technical Skills:</b> " + skills + " </p>";




}
